package com.alex.assistant

data class VoiceProfile(val name: String, val emoji: String, val pitch: Float, val rate: Float)

object VoiceProfiles {
    val all = listOf(
        VoiceProfile("Алекс (обычный)", "🤖", 1.0f, 1.05f),
        VoiceProfile("Дарт Вейдер", "🌑", 0.35f, 0.75f),
        VoiceProfile("Йода", "🐸", 1.7f, 0.70f),
        VoiceProfile("Миньон", "🍌", 2.0f, 1.45f),
        VoiceProfile("Шрек", "👹", 0.55f, 0.85f),
        VoiceProfile("Микки Маус", "🐭", 1.9f, 1.15f),
        VoiceProfile("Бэтмен", "🦇", 0.30f, 0.80f),
        VoiceProfile("Гомер Симпсон", "🍩", 0.55f, 0.95f),
        VoiceProfile("Чипмунк", "🐿️", 2.0f, 1.70f),
        VoiceProfile("Железный человек", "🦾", 0.80f, 1.10f),
        VoiceProfile("Горлум", "💍", 1.5f, 0.85f),
        VoiceProfile("Робот-стар", "📟", 0.60f, 1.25f),
        VoiceProfile("Марио", "🍄", 1.6f, 1.20f),
        VoiceProfile("Пиратская зануда", "🏴‍☠️", 0.45f, 0.70f)
    )
}
