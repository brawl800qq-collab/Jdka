package com.alex.assistant

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("alex_prefs", Context.MODE_PRIVATE)
    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("key", v.trim()).apply()
    fun model(c: Context): String = sp(c).getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v.trim()).apply()
    fun voice(c: Context): Int = sp(c).getInt("voice", 0)
    fun setVoice(c: Context, i: Int) = sp(c).edit().putInt("voice", i).apply()
}
