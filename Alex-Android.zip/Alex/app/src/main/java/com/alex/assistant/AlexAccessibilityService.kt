package com.alex.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class AlexAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: AlexAccessibilityService? = null

        private val ALIASES = mapOf(
            "ютуб" to listOf("youtube"), "youtube" to listOf("youtube"),
            "телеграм" to listOf("telegram"), "телега" to listOf("telegram"),
            "вотсап" to listOf("whatsapp"), "ватсап" to listOf("whatsapp"),
            "хром" to listOf("chrome"), "браузер" to listOf("chrome", "браузер", "browser"),
            "настройки" to listOf("settings", "настройки"),
            "камера" to listOf("camera", "камера"),
            "галерея" to listOf("gallery", "галерея", "photos", "фото"),
            "вк" to listOf("vk", "вконтакте"), "вконтакте" to listOf("vk", "вконтакте"),
            "инстаграм" to listOf("instagram"), "тикток" to listOf("tiktok"),
            "карты" to listOf("maps", "карты"), "почта" to listOf("gmail", "почта", "mail"),
            "калькулятор" to listOf("calculator", "калькулятор"),
            "телефон" to listOf("phone", "телефон", "dialer"),
            "сообщения" to listOf("messages", "сообщения"),
            "плей маркет" to listOf("play store", "google play"), "гугл плей" to listOf("play store"),
            "спотифай" to listOf("spotify"), "нетфликс" to listOf("netflix")
        )
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    fun screenshotBlocking(): Bitmap? {
        for (attempt in 0..1) {
            val latch = CountDownLatch(1)
            var out: Bitmap? = null
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        out = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    } finally {
                        result.hardwareBuffer.close()
                    }
                    latch.countDown()
                }
                override fun onFailure(errorCode: Int) { latch.countDown() }
            })
            latch.await(4, TimeUnit.SECONDS)
            if (out != null) return out
            Thread.sleep(1100)
        }
        return null
    }

    fun tap(x: Float, y: Float) = gesture(x, y, x, y, 60)
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) = gesture(x1, y1, x2, y2, 380)

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val p = Path()
        p.moveTo(x1, y1)
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        dispatchGesture(g, null, null)
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun inputNode(): AccessibilityNodeInfo? =
        findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(rootInActiveWindow)

    fun typeText(t: String): Boolean {
        val node = inputNode() ?: return false
        val base = if (node.isShowingHintText) "" else (node.text?.toString() ?: "")
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + t)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressEnter(): Boolean {
        val node = inputNode() ?: return false
        return node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val list: List<ResolveInfo> = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val q = name.lowercase().trim()
        val tries = listOf(q) + (ALIASES[q] ?: emptyList())
        fun label(r: ResolveInfo) = r.loadLabel(pm).toString().lowercase()
        var hit: ResolveInfo? = null
        for (t in tries) {
            hit = list.firstOrNull { label(it) == t }
                ?: list.firstOrNull { label(it).contains(t) }
                ?: list.firstOrNull { it.activityInfo.packageName.contains(t.replace(" ", "")) }
            if (hit != null) break
        }
        if (hit == null) hit = list.firstOrNull { label(it).length > 2 && q.contains(label(it)) }
        val h = hit ?: return false
        val launch = pm.getLaunchIntentForPackage(h.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }
}
