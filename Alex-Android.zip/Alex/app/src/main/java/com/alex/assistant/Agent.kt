package com.alex.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

interface AgentHost {
    fun say(text: String)
    fun status(text: String)
    fun ghost(on: Boolean)
    fun finished()
}

class Agent(private val ctx: Context, private val host: AgentHost) {
    @Volatile var cancelled = false
    @Volatile var running = false
    private val memory = ArrayList<String>()

    companion object {
        private const val SYSTEM = """Ты — Алекс, умный голосовой помощник на Android-телефоне пользователя. Говори по-русски, коротко и дружелюбно (1-2 предложения).
Тебе дают задачу и (если есть) скриншот экрана. Выполняй задачу по ОДНОМУ действию за шаг.
Отвечай ТОЛЬКО одним JSON-объектом без пояснений:
{"speech":"что сказать вслух","action":"...","x":0,"y":0,"x2":0,"y2":0,"text":"","app":""}
Координаты x,y — в системе 0..1000 (x слева направо, y сверху вниз) относительно скриншота.
Допустимые action: tap, swipe (из x,y в x2,y2), type (поле text), enter, open_app (поле app — название приложения как на телефоне), back, home, recents, scroll_down, scroll_up, wait, done.
Правила:
- Приложения открывай через open_app, а не ищи иконку вручную.
- Перед type сначала нажми tap на поле ввода, если оно не в фокусе.
- Если на вопрос можно просто ответить — action=done, ответ в speech.
- Когда задача выполнена — action=done и короткий итог в speech.
- Если действие не помогло, не повторяй его — попробуй другое.
- Перед необратимыми действиями (оплата, перевод денег, удаление, отправка важного) не делай их, а спроси подтверждение через action=done.
- speech на промежуточных шагах оставляй пустым или очень коротким."""
    }

    fun run(goal: String) {
        running = true
        cancelled = false
        try {
            loop(goal)
        } catch (e: GeminiClient.GeminiException) {
            host.say(
                when (e.code) {
                    429 -> "Лимит бесплатных запросов Gemini закончился. Подожди минутку."
                    400, 401, 403 -> "Gemini не принял ключ. Проверь ключ в приложении."
                    404 -> "Такой модели Gemini нет. Проверь название модели."
                    else -> "Ошибка Gemini ${e.code}."
                }
            )
        } catch (e: java.io.IOException) {
            host.say("Нет связи с интернетом.")
        } catch (e: Exception) {
            host.say("Что-то пошло не так.")
        } finally {
            running = false
            host.finished()
        }
    }

    private fun loop(goal: String) {
        val key = Prefs.apiKey(ctx)
        if (key.isBlank()) { host.say("Вставь ключ Gemini в настройках приложения."); return }
        val acc = AlexAccessibilityService.instance
        val dm = ctx.resources.displayMetrics
        val history = ArrayList<String>()
        var lastSpeech = ""
        val maxSteps = if (acc == null) 1 else 14

        for (step in 1..maxSteps) {
            if (cancelled) { host.say("Остановился."); break }
            var jpeg: ByteArray? = null
            var w = dm.widthPixels
            var h = dm.heightPixels
            if (acc != null) {
                host.status("Смотрю на экран…")
                host.ghost(true); Thread.sleep(220)
                val bmp = acc.screenshotBlocking()
                host.ghost(false)
                if (bmp != null) { w = bmp.width; h = bmp.height; jpeg = toJpeg(bmp) }
            }
            if (cancelled) { host.say("Остановился."); break }
            host.status("Думаю…")
            val raw = GeminiClient.generate(key, Prefs.model(ctx), SYSTEM, prompt(goal, step, history, jpeg != null), jpeg)
            val j = parse(raw)
            val speech = j.optString("speech", "").trim()
            if (speech.isNotEmpty()) { host.say(speech); lastSpeech = speech }
            val action = j.optString("action", "done")
            if (action == "done" || action == "none" || acc == null) break
            if (cancelled) { host.say("Остановился."); break }

            host.status("Делаю: $action")
            host.ghost(true); Thread.sleep(150)
            val desc: String = when (action) {
                "tap" -> { acc.tap(cx(j, "x", w), cx(j, "y", h)); "нажал (${j.optInt("x")},${j.optInt("y")})" }
                "swipe" -> {
                    acc.swipe(cx(j, "x", w), cx(j, "y", h), cx(j, "x2", w), cx(j, "y2", h)); "свайп"
                }
                "scroll_down" -> { acc.swipe(w * .5f, h * .72f, w * .5f, h * .28f); "прокрутил вниз" }
                "scroll_up" -> { acc.swipe(w * .5f, h * .28f, w * .5f, h * .72f); "прокрутил вверх" }
                "type" -> {
                    val t = j.optString("text", "")
                    val ok = acc.typeText(t)
                    if (ok) "ввёл текст «$t»" else "не смог ввести текст (нет активного поля)"
                }
                "enter" -> if (acc.pressEnter()) "нажал Enter" else "Enter не сработал"
                "open_app" -> {
                    val a = j.optString("app", "")
                    if (acc.openApp(a)) "открыл приложение $a" else "приложение $a не найдено"
                }
                "back" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); "назад" }
                "home" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); "домой" }
                "recents" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); "недавние" }
                "wait" -> { Thread.sleep(1500); "подождал" }
                else -> "неизвестное действие $action"
            }
            Thread.sleep(350)
            host.ghost(false)
            history.add(desc)
            Thread.sleep(1100)
        }
        memory.add("Пользователь: $goal")
        if (lastSpeech.isNotEmpty()) memory.add("Алекс: $lastSpeech")
        while (memory.size > 8) memory.removeAt(0)
    }

    private fun prompt(goal: String, step: Int, history: List<String>, hasImage: Boolean): String {
        val sb = StringBuilder()
        if (memory.isNotEmpty()) sb.append("Недавний разговор:\n").append(memory.joinToString("\n")).append("\n\n")
        sb.append("Задача пользователя: ").append(goal).append("\n")
        sb.append(
            if (hasImage) "К сообщению приложен текущий скриншот экрана.\n"
            else "Скриншота нет (управление телефоном не включено) — только отвечай словами.\n"
        )
        if (history.isNotEmpty()) sb.append("Уже сделано: ").append(history.joinToString("; ")).append("\n")
        sb.append("Шаг ").append(step).append(". Верни JSON со следующим действием.")
        return sb.toString()
    }

    private fun parse(raw: String): JSONObject {
        val s = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            if (s.startsWith("[")) JSONArray(s).getJSONObject(0) else JSONObject(s)
        } catch (e: Exception) {
            try {
                JSONObject(s.substring(s.indexOf('{'), s.lastIndexOf('}') + 1))
            } catch (e2: Exception) {
                JSONObject().put("speech", s).put("action", "done")
            }
        }
    }

    private fun cx(j: JSONObject, k: String, size: Int): Float =
        (j.optDouble(k, 500.0) / 1000.0 * size).toFloat().coerceIn(0f, size - 1f)

    private fun toJpeg(src: Bitmap): ByteArray {
        val max = 1000f
        val scale = minOf(1f, max / maxOf(src.width, src.height))
        val b = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return out.toByteArray()
    }
}
